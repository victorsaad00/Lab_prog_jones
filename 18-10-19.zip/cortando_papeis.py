import statistics

def cortar(altura, papeis):

    peças = 2
    pico = 0 

    for i in range(1, len(papeis)):
        if (i+1) <= len(papeis) + 1:

            if (papeis[i] <= altura) and (papeis[i-1] > altura): pico += 1

            if (papeis[i] <= altura) and (papeis[i+1] > altura): pico += 1

        if pico == 2:

            peças += 1
            pico = 0
    
    return peças

def main():
    
    n = int(input())
    papeis = [int(i) for i in input().split()]
    papeis_ord = sorted(papeis)  

    greater = 0
    index = 0

    for i in range(0, len(papeis_ord)):
        if i > 0 and (greater < papeis_ord[i] - papeis_ord[i-1]):

            greater = papeis_ord[i] - papeis_ord[i-1]
            index = i

    menores = papeis_ord[:index]
    moda = statistics.mode(menores)

    print(cortar(moda, papeis))    

main()

